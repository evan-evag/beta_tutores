<?php
require_once __DIR__ . '/includes/init.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
redirigir('index.php');
